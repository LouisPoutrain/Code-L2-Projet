package systeme;

public class Affectation {
	
	
	private long idAffectation;
	private Creneau creneau;
	private PersonnelHospitalier personnel;
	
	public Affectation(long idAffectation, Creneau creneau, PersonnelHospitalier personnel) {
		this.idAffectation=idAffectation;
		this.creneau=creneau;
		this.personnel=personnel;
	}
	public Affectation() {
		super();
	}
	public long getId() {
		return idAffectation;
	}
	public void setId(long id) {
		idAffectation=id;
	}
	public Creneau getCreneau() {
		return creneau;
	}
	public PersonnelHospitalier getPersonnel() {
		return personnel;
	}
	@Override
	public String toString() {
		return "Affectation [idAffectation=" + idAffectation + ", creneau=" + creneau + ", personnel=" + personnel
				+ "]";
	}
	
	public void setCreneau(Creneau creneau) {
		this.creneau = creneau;
	}
	public void setPersonnel(PersonnelHospitalier personnel) {
		this.personnel = personnel;
	}
	

}
