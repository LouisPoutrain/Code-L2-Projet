package systeme;

public class Contrainte {
	private long idContrainte;
	private String typeValeur;
	private int valeur;
	
	public Contrainte(long idContrainte, String typeValeur, int valeur) {
		this.idContrainte=idContrainte;
		this.typeValeur=typeValeur;
		this.valeur=valeur;
	}
	@Override
	public String toString() {
		return "Contrainte [idContrainte=" + idContrainte + ", typeValeur=" + typeValeur + ", valeur=" + valeur + "]";
	}
	public Contrainte() {
		super();
	}
	public long getId() {
		return idContrainte;
	}
	public void setId(long id) {
		idContrainte=id;
	}
	public String getTypeValeur() {
		return typeValeur;
	}
	public void setTypeValeur(String typeValeur) {
		this.typeValeur = typeValeur;
	}
	public int getValeur() {
		return valeur;
	}
	public void setValeur(int valeur) {
		this.valeur = valeur;
	}

}
