package systeme;

public class PersonnelHospitalier {
	
	private long idPersonnel;
	private String nom;
	private String prenom;
	private Fonction fonction;
	private Specialite specialite;
	private float Tpstravailmensuel;
	
	public PersonnelHospitalier() {
		super();
	}
	public PersonnelHospitalier(long idPersonnel, String nom, String prenom, Fonction fonction, Specialite specialite, float Tpstravailmensuel) {
		this.idPersonnel=idPersonnel;
		this.nom=nom;
		this.prenom=prenom;
		this.fonction=fonction;
		this.specialite=specialite;
		this.Tpstravailmensuel=Tpstravailmensuel;
	}
	public long getId() {
		return idPersonnel;
	}
	public void setId(long id) {
		idPersonnel=id;
	}
	public void setIdPersonnel(int idPersonnel) {
		this.idPersonnel = idPersonnel;
	}
	@Override
	public String toString() {
		return "PersonnelHospitalier [idPersonnel=" + idPersonnel + ", nom=" + nom + ", prenom=" + prenom
				+ ", fonction=" + fonction + ", specialite=" + specialite + ", Tpstravailmensuel=" + Tpstravailmensuel
				+ "]";
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public Fonction getFonction() {
		return fonction;
	}
	public void setFonction(Fonction fonction) {
		this.fonction = fonction;
	}
	public Specialite getSpecialite() {
		return specialite;
	}
	public void setSpecialite(Specialite specialite) {
		this.specialite = specialite;
	}
	public float getTpstravailmensuel() {
		return Tpstravailmensuel;
	}
	public void setTpstravailmensuel(float tpstravailmensuel) {
		Tpstravailmensuel = tpstravailmensuel;
	}
	

}
