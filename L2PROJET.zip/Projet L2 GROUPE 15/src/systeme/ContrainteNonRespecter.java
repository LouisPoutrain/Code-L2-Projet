package systeme;

public class ContrainteNonRespecter {
	private long idContrainteNonRespecter;
	private Creneau creneau;
	private Contrainte contrainte;
	
	public ContrainteNonRespecter(long idContrainteNonRespecter, Creneau creneau, Contrainte contrainte) {
		this.idContrainteNonRespecter=idContrainteNonRespecter;
		this.creneau=creneau;
		this.contrainte=contrainte;
	}
	@Override
	public String toString() {
		return "ContrainteNonRespecter [idContrainteNonRespecter=" + idContrainteNonRespecter + ", creneau=" + creneau
				+ ", contrainte=" + contrainte + "]";
	}
	public ContrainteNonRespecter() {
		super();
	}
	public long getId() {
		return idContrainteNonRespecter;
	}
	public void setId(long idContrainteNonRespecter) {
		this.idContrainteNonRespecter = idContrainteNonRespecter;
	}
	public Creneau getCreneau() {
		return creneau;
	}
	public Contrainte getContrainte() {
		return contrainte;
	}

}
