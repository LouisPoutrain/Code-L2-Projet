package systeme;

public class Creneau {
	
	
	private Long idCreneau;
	private String date;
	private String debutPlage;
	private String finPlage;
	private int besoinMinPersonnel;
	private String besoinEnSpecialite;

	public String toString() {
		return "Creneau [idCreneau=" + idCreneau + ", date=" + date + ", debutPlage=" + debutPlage + ", finPlage="
				+ finPlage + ", besoinMinPersonnel=" + besoinMinPersonnel + ", besoinEnSpecialite=" + besoinEnSpecialite
				+ "]";
	}
	public Creneau(Long idCreneau, String date, String debutPlsge, String finPlage, int besionMinPersonnel, String besoinEnSpecialite) {
		this.idCreneau=idCreneau;
		this.date=date;
		this.debutPlage=debutPlsge;
		this.finPlage=finPlage;
		this.besoinEnSpecialite=besoinEnSpecialite;
		this.besoinMinPersonnel=besionMinPersonnel;
		
	}
	
	public Creneau() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return idCreneau;
	}
	public void setId(Long id) {
		idCreneau=id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDebutPlage() {
		return debutPlage;
	}
	public void setDebutPlage(String debutPlage) {
		this.debutPlage = debutPlage;
	}
	public String getFinPlage() {
		return finPlage;
	}
	public void setFinPlage(String finPlage) {
		this.finPlage = finPlage;
	}
	public int getBesoinMinPersonnel() {
		return besoinMinPersonnel;
	}
	public void setBesoinMinPersonnel(int besoinMinPersonnel) {
		this.besoinMinPersonnel = besoinMinPersonnel;
	}
	public String getBesoinEnSpecialite() {
		return besoinEnSpecialite;
	}
	public void setBesoinEnSpecialite(String besoinEnSpecialite) {
		this.besoinEnSpecialite = besoinEnSpecialite;
	}
	
}
