package systeme;

public class CadreDeSante {
	private long identifiant;
	private String nom;
	private String prenom;
	private String motdepasse;
	public CadreDeSante(long identifiant, String nom, String prenom, String motdepasse) {
		this.identifiant=identifiant;
		this.nom=nom;
		this.prenom=prenom;
		this.motdepasse=motdepasse;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public void setMotdepasse(String motdepasse) {
		this.motdepasse = motdepasse;
	}
	public CadreDeSante() {
		super();
	}
	@Override
	public String toString() {
		return "CadreDeSante [identifiant=" + identifiant + ", nom=" + nom + ", prenom=" + prenom + ", motdepasse="
				+ motdepasse + "]";
	}
	public long getId() {
		return identifiant;
	}
	public void setId(long id) {
		identifiant=id;
	}
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public String getMotdepasse() {
		return motdepasse;
	}
}
