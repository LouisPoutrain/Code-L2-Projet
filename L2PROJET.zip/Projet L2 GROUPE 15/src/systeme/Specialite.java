package systeme;

public class Specialite {
	
	private long idSpecialite;
	private String nom;
	private float tempsMax;
	
	 public Specialite() {
	        // Vous pouvez initialiser des valeurs par défaut si nécessaire
	        this.idSpecialite = 0;
	        this.nom = "";
	        this.tempsMax = 0;
	    }
	 
	 public Specialite(long idSpecialite, String nom, float tempsMax) {
		this.idSpecialite=idSpecialite;
		this.nom=nom;
		this.tempsMax=tempsMax;
	}
	public long getId() {
		return idSpecialite;
	}
	public void setId(long id) {
		idSpecialite=id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public float getTempsMax() {
		return tempsMax;
	}
	public void setTempsMax(float tempsMax) {
		this.tempsMax = tempsMax;
	}
	@Override
    public String toString() {
        return "Specialite{" +
                "id=" + idSpecialite +
                ", nom='" + nom + '\'' +
                ", tempsMax=" + tempsMax +
                '}';
    }}

