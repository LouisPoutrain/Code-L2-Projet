package FX;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import systeme.CadreDeSante;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import DAO.CadreDeSanteDAO;

public class MainFX extends Application {

    private Map<String, Class<? extends Stage>> optionWindowMap = new HashMap<>();
    private StackPane stackPane;
    private Button button;
    private Button button1;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        stackPane = new StackPane();
        button = new Button("Menu");
        button1 = new Button("Se Connecter");

        stackPane.getChildren().add(button1);

        optionWindowMap.put("Specialite", SpecialiteFX.class);
        optionWindowMap.put("Personnel", PersonnelFX.class);
        optionWindowMap.put("Creneau", CreneauFX.class);
        optionWindowMap.put("Affectation", AffectationFX.class);
        optionWindowMap.put("Fonction", FonctionFX.class);
        optionWindowMap.put("Contrainte", ContrainteFX.class);
        optionWindowMap.put("Contrainte Non Respecter", ContrainteNonRespecterFX.class);
        optionWindowMap.put("Espace Cadre", CadreDeSanteFX.class);

        primaryStage.setTitle("Planification Hospitalier");

        ContextMenu contextMenu = new ContextMenu();

        button1.setOnMouseClicked(e -> {
            boolean isConnected = connexion();
            gestionAffichageBouton(isConnected);
        });

        for (String optionName : optionWindowMap.keySet()) {
            MenuItem item = new MenuItem(optionName);

            item.setOnAction(e -> openNewWindow(optionName));

            contextMenu.getItems().add(item);
        }

        button.setOnMouseClicked(e -> {
            contextMenu.show(button, e.getScreenX(), e.getScreenY());
            e.consume();
            gestionAffichageBouton(true);
        });

        primaryStage.setScene(new Scene(stackPane, 300, 200));
        primaryStage.show();
    }

    private void openNewWindow(String optionName) {
        try {
            Class<? extends Stage> windowClass = optionWindowMap.get(optionName);
            if (windowClass != null) {
                Stage window = windowClass.getDeclaredConstructor().newInstance();
                window.show();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void gestionAffichageBouton(boolean isConnected) {
        if (isConnected) {
            stackPane.getChildren().remove(button1);
            if (!stackPane.getChildren().contains(button)) {
                stackPane.getChildren().add(button);
            }
        } else {
            stackPane.getChildren().remove(button);
            if (!stackPane.getChildren().contains(button1)) {
                stackPane.getChildren().add(button1);
            }
        }
    }

    private boolean connexion() {
        Formulaire formulaire = new Formulaire(List.of("Identifiant", "Mot De Passe"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();
        CadreDeSanteDAO cadre = new CadreDeSanteDAO();

        final boolean[] isConnected = {false};  

        result.ifPresent(values -> {
            if (values.size() == 2) {
                CadreDeSante CDS = cadre.afficherUnCadreDeSante(Integer.parseInt(values.get(0)));
                if (CDS != null && values.get(1).equals(CDS.getMotdepasse())) {
                    isConnected[0] = true;
                }
            }
        });

        gestionAffichageBouton(isConnected[0]);

        return isConnected[0];
    }
}
