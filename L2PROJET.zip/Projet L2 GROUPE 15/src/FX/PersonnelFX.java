package FX;

import DAO.SpecialiteDAO;
import DAO.FonctionDAO;
import systeme.Creneau;
import systeme.Fonction;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;
import DAO.PersonnelHospitalierDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.PersonnelHospitalier;
import systeme.Specialite;

public class PersonnelFX extends Stage {
	
	
	

    public PersonnelFX() {
        setTitle("Personnel");

        ListView<String> personnelListView1 = new ListView<>();
       

        Button afficherPersonnelButton = new Button("Afficher Tout le Personnel");
        afficherPersonnelButton.setOnAction(e -> {
            List<String> personnelInfos = afficherToutPersonnel();
            ObservableList<String> items = FXCollections.observableArrayList(personnelInfos);
            personnelListView1.setItems(items);
        });
        
        Button supprimerPersonnelButton = new Button("Supprimer Personnel");
        supprimerPersonnelButton.setOnAction(e -> supprimerPersonnel());
        
        Button modifierPersonnelButton = new Button("Modifier un Personnel");
        modifierPersonnelButton.setOnAction(e -> modifierPersonnel());
        
        Button ajouterPersonnelButton = new Button("Ajouter Personnel");
        ajouterPersonnelButton.setOnAction(e -> ajouterPersonnel());
        
        Button afficherInfosPersonnel = new Button("Afficher Infos De Un Personnel");
        afficherInfosPersonnel.setOnAction(e ->  {
            List<String> personnelInfos = afficherInfosPersonnel();
            ObservableList<String> items = FXCollections.observableArrayList(personnelInfos);
            personnelListView1.setItems(items);
        });
        
        Button afficherEDTPersonnel = new Button("Afficher Emploi Du Temps Personnel");
        afficherEDTPersonnel.setOnAction(e -> {
            Map<String, String> emploiDuTemps = afficherEDTPersonnel();
            Map<String, String> emploiDuTemps1 = new TreeMap<>(emploiDuTemps);
            // Convertir le Map en une liste de chaînes pour l'ObservableList
            List<String> emploiDuTempsList = emploiDuTemps1.entrySet().stream()
                    .map(entry -> entry.getKey() + ": " + entry.getValue())
                    .collect(Collectors.toList());

            ObservableList<String> items = FXCollections.observableArrayList(emploiDuTempsList);
            personnelListView1.setItems(items);
        });
        
        
        VBox root = new VBox();
        root.getChildren().addAll(afficherEDTPersonnel,afficherPersonnelButton, ajouterPersonnelButton,supprimerPersonnelButton,afficherInfosPersonnel,modifierPersonnelButton,personnelListView1);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);
    }

    private List<String> afficherToutPersonnel() {
        PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
        List<String> personnelInfo = personnelDAO.afficherToutPersonnel().stream()
                .map(personnel -> personnel.getId() + " " + personnel.getPrenom()+" "+personnel.getNom())
                .collect(Collectors.toList());
        return personnelInfo;
    }
    
    private void supprimerPersonnel() {
        Formulaire formulaire = new Formulaire(List.of("id"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 1) {
                try {
                    long id = Long.parseLong(values.get(0));

                    // Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
                    PersonnelHospitalier personnel = new PersonnelHospitalier();
                    PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
                    personnel = personnelDAO.afficherPersonnelSpecific(id);
                    personnelDAO.delete(personnel);

                } catch (NumberFormatException e) {
                    System.out.println("Erreur : Format numérique invalide.");
                }

            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }


    private void ajouterPersonnel() {
        Formulaire formulaire = new Formulaire(List.of("nom","prenom","specialité","TempsTravailleMensuel","fonction"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 5) {
                String nom = values.get(0);
                String prenom = values.get(1);
                String specialiteNom = values.get(2);
                int tpsTravaille = Integer.parseInt(values.get(3));
                String fonctionNom = values.get(4);
                
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                Specialite specialite = new Specialite();
                specialite = specialiteDAO.afficherUneSpecialiteNom(specialiteNom);
                
                FonctionDAO fonctionDAO = new FonctionDAO();
                Fonction fonction = new Fonction();
                fonction = fonctionDAO.afficherUneFonctionNom(fonctionNom);

                PersonnelHospitalier personnel = new PersonnelHospitalier();
                personnel.setNom(nom);
                personnel.setPrenom(prenom);
                personnel.setSpecialite(specialite);
                personnel.setTpstravailmensuel(tpsTravaille);
                personnel.setFonction(fonction);

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
                personnelDAO.create(personnel);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
    
    private void modifierPersonnel() {
        Formulaire formulaire = new Formulaire(List.of("id du personnel à modifier","nom","prenom","specialité","TempsTravailleMensuel","fonction"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 6) {
            	long id = Integer.parseInt(values.get(0));
                String nom = values.get(1);
                String prenom = values.get(2);
                String specialiteNom = values.get(3);
                int tpsTravaille = Integer.parseInt(values.get(4));
                String fonctionNom = values.get(5);
                
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                Specialite specialite = new Specialite();
                specialite = specialiteDAO.afficherUneSpecialiteNom(specialiteNom);
                
                FonctionDAO fonctionDAO = new FonctionDAO();
                Fonction fonction = new Fonction();
                fonction = fonctionDAO.afficherUneFonctionNom(fonctionNom);

                PersonnelHospitalier personnel = new PersonnelHospitalier();
                personnel.setId(id);
                personnel.setNom(nom);
                personnel.setPrenom(prenom);
                personnel.setSpecialite(specialite);
                personnel.setTpstravailmensuel(tpsTravaille);
                personnel.setFonction(fonction);

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
                personnelDAO.update(personnel);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
    
    public List<String> afficherInfosPersonnel() {
        Formulaire formulaire = new Formulaire(List.of("id"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();
        PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
        
        // Initialiser la liste
        List<String> personnelInfos = new ArrayList<>();

        // Récupérer les informations du personnel par ID
        result.ifPresent(values -> {
            if (values.size() == 1) {
                long id = Long.parseLong(values.get(0));
                PersonnelHospitalier personnel = personnelDAO.afficherPersonnelSpecific(id);
                if (personnel != null) {
                    // Récupérer les informations supplémentaires (spécialité, fonction, etc.)
                    Specialite specialite = personnel.getSpecialite();
                    Fonction fonction = personnel.getFonction();

                    // Ajouter les informations à la liste
                    personnelInfos.add("Id : " + personnel.getId());
                    personnelInfos.add("Nom : " + personnel.getNom());
                    personnelInfos.add("Prénom : " + personnel.getPrenom());
                    personnelInfos.add("Spécialité : " + specialite.getNom());
                    personnelInfos.add("Fonction : " + fonction.getNom());
                    personnelInfos.add("Temps Travail Mensuel : " + personnel.getTpstravailmensuel());
                    
                   
                } else {
                    System.out.println("Personnel non trouvé avec l'ID : " + id);
                }
            }
        });
		return personnelInfos;
    }
    
    public Map<String, String> afficherEDTPersonnel() {
        Formulaire formulaire = new Formulaire(List.of("id"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();
        PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
        
        // Initialiser la liste
        Map<String,String> EDT = new HashMap<>();

        // Récupérer les informations du personnel par ID
        result.ifPresent(values -> {
            if (values.size() == 1) {
                List<Creneau> edt = personnelDAO.afficherEmploieDuTempsDunPersonnel(Long.parseLong(values.get(0)));
                for (int i = 0; i <edt.size() ; i++) {
                	if (EDT.containsKey(edt.get(i).getDate())){
                		String value = EDT.get(edt.get(i).getDate());
                		value = value+" "+edt.get(i).getDebutPlage()+"-"+edt.get(i).getFinPlage();
                		EDT.put(edt.get(i).getDate(),value);
                		
                	}else {
                		EDT.put(edt.get(i).getDate(),edt.get(i).getDebutPlage()+"-"+edt.get(i).getFinPlage());
                		
                	}
                	}
                	
                }
               
         
        	});
        
        
        	
        
		return EDT;
    }

   	 
    
  }



