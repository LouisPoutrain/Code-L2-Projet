package FX;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.SpecialiteDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Specialite;

public class SpecialiteFX extends Stage {
    public SpecialiteFX() {
        setTitle("Specialite");
        
        ListView<String> specialitesListView = new ListView<>();

        Button afficherSpecialitesButton = new Button("Afficher Toutes les Spécialités");
        afficherSpecialitesButton.setOnAction(e -> {
            List<String> specialitesNoms = afficherToutesSpecialites();
            ObservableList<String> items = FXCollections.observableArrayList(specialitesNoms);
            specialitesListView.setItems(items);
        });
        
        Button supprimerSpecialiteButton = new Button("Supprimer Specialite");
        supprimerSpecialiteButton.setOnAction(e -> supprimerSpecialite());
        
        Button modifierSpecialiteButton = new Button("Modifier une Specialite");
        modifierSpecialiteButton.setOnAction(e -> modifierSpecialite());
        
        Button ajouterSpecialiteButton = new Button("Ajouter Specialite");
        ajouterSpecialiteButton.setOnAction(e -> ajouterSpecialite());

        VBox root = new VBox();
        root.getChildren().addAll(afficherSpecialitesButton, ajouterSpecialiteButton,modifierSpecialiteButton,supprimerSpecialiteButton,specialitesListView);

        Scene scene = new Scene(root, 300, 200);
        setScene(scene);
    }

    private List<String> afficherToutesSpecialites() {
        SpecialiteDAO specialiteDAO = new SpecialiteDAO();
        List<String> specialitesNoms = specialiteDAO.afficherToutSpecialite().stream()
                .map(specialite -> specialite.getId() + " " + specialite.getNom())
                .collect(Collectors.toList());

        return specialitesNoms;
    }
    
    private void supprimerSpecialite() {
        Formulaire formulaire = new Formulaire(List.of("id"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 1) {
            	long idSpecialite = Long.parseLong(values.get(0));
                
            	SpecialiteDAO specialiteDAO = new SpecialiteDAO();
            	
                Specialite specialite = specialiteDAO.afficherUneSpecialite(idSpecialite);
                

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                
                specialiteDAO.delete(specialite);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
    private void ajouterSpecialite() {
        Formulaire formulaire = new Formulaire(List.of("Nom de la spécialité", "Temps maximal"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 2) {
                String nomSpecialite = values.get(0);
                int tempsMaximal = Integer.parseInt(values.get(1));

                Specialite nouvelleSpecialite = new Specialite();
                nouvelleSpecialite.setNom(nomSpecialite);
                nouvelleSpecialite.setTempsMax(tempsMaximal);

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                specialiteDAO.create(nouvelleSpecialite);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
    private void modifierSpecialite() {
        Formulaire formulaire = new Formulaire(List.of("id de la  Specialite à modifier","nom"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 2) {
            	long id = Integer.parseInt(values.get(0));
            	String nom = values.get(1);            

                Specialite specialite = new Specialite();
                specialite.setId(id);
                specialite.setNom(nom);               
                

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                specialiteDAO.update(specialite);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
}



