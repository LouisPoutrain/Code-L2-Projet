package FX;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.FonctionDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Fonction;

public class FonctionFX extends Stage{
	
	public FonctionFX() {
		 
        setTitle("Fonction");
        
        ListView<String> fonctionsListView = new ListView<>();

        Button afficherFonctionsButton = new Button("Afficher Toutes les Fonction");
        afficherFonctionsButton.setOnAction(e -> {
            List<String> fonctionsNoms = afficherToutesFonctions();
            ObservableList<String> items = FXCollections.observableArrayList(fonctionsNoms);
            fonctionsListView.setItems(items);
        });

        Button supprimerFonctionButton = new Button("Supprimer Fonction");
        supprimerFonctionButton.setOnAction(e -> supprimerFonction());
        
        Button modifierFonctionButton = new Button("Modifier une Fonction");
        modifierFonctionButton.setOnAction(e -> modifierFonction());
        
        Button ajouterFonctionlButton = new Button("Ajouter Fonction");
        ajouterFonctionlButton.setOnAction(e -> ajouterFonction());
        
        VBox root = new VBox();
        root.getChildren().addAll(modifierFonctionButton,supprimerFonctionButton,ajouterFonctionlButton,afficherFonctionsButton,fonctionsListView);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);

}
		private List<String> afficherToutesFonctions() {
			FonctionDAO fonctionDAO = new FonctionDAO();
			List<String> fonctionsNoms = fonctionDAO.afficherToutFonction().stream()
					.map(fonction -> fonction.getId() + " " + fonction.getNom())
					.collect(Collectors.toList());

			return fonctionsNoms;
 }
	
		private void supprimerFonction() {
				Formulaire formulaire = new Formulaire(List.of("id"));
				Optional<List<String>> result = formulaire.afficherEtAttendre();

				result.ifPresent(values -> {
            
					if (values.size() == 1) {
						try {
							long id = Long.parseLong(values.get(0));

							// Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
							Fonction fonction = new Fonction();
							FonctionDAO fonctionDAO = new FonctionDAO();
							fonction = fonctionDAO.afficherUneFonction(id);
							fonctionDAO.delete(fonction);

							} catch (NumberFormatException e) {
								System.out.println("Erreur : Format numérique invalide.");
												}

					} else {
						// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
						System.out.println("Erreur : Nombre de valeurs incorrect.");
								}
        });
    }
	
		





		private void ajouterFonction() {
	        	Formulaire formulaire = new Formulaire(List.of("nom"));
	        	Optional<List<String>> result = formulaire.afficherEtAttendre();

	        	result.ifPresent(values -> {
	        		// Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	        		if (values.size() == 1) {
	        			String nom = values.get(0);      			
	        			
	                    Fonction fonction = new Fonction();
	                	fonction.setNom(nom);                	
	                	

	                	// Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                	FonctionDAO fonctionDAO = new FonctionDAO();
	                	fonctionDAO.create(fonction);
	                
	                
	        		} else {
	        			// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	        			System.out.println("Erreur : Nombre de valeurs incorrect.");
	        		}
	        	});
			}
	
		




		private void modifierFonction() {
	        Formulaire formulaire = new Formulaire(List.of("id de la  Fonction à modifier","nom"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 2) {
	            	long id = Integer.parseInt(values.get(0));
	            	String nom = values.get(1);            

	                Fonction fonction = new Fonction();
	                fonction.setId(id);
	                fonction.setNom(nom);               
	                

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                FonctionDAO fonctionDAO = new FonctionDAO();
	                fonctionDAO.update(fonction);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	
		
	
}

