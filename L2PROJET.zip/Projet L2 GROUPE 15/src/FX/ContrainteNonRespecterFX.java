package FX;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.AffectationDAO;
import DAO.ContrainteNonRespecterDAO;
import DAO.CreneauDAO;
import DAO.PersonnelHospitalierDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Affectation;
import systeme.Contrainte;
import systeme.ContrainteNonRespecter;
import systeme.Creneau;
import systeme.PersonnelHospitalier;

public class ContrainteNonRespecterFX extends Stage{
	
	public ContrainteNonRespecterFX() {
		
		setTitle("Contrainte Non Respecter");
		
		ListView<String> contrainteNonRespectersListView = new ListView<>();

        Button afficherContrainteNonRespectersButton = new Button("Afficher Toutes les ContrainteNonRespecter");
        afficherContrainteNonRespectersButton.setOnAction(e -> {
            List<String> contrainteNonRespectersNoms = afficherToutesContrainteNonRespecters();
            ObservableList<String> items = FXCollections.observableArrayList(contrainteNonRespectersNoms);
            contrainteNonRespectersListView.setItems(items);
        });
        
        Button afficherUneContrainteNonRespectersButton = new Button("Afficher Infos de Une ContrainteNonRespecter");
        afficherUneContrainteNonRespectersButton.setOnAction(e -> {
            List<String> contrainteNonRespectersNoms = afficherInfosCNR();
            ObservableList<String> items = FXCollections.observableArrayList(contrainteNonRespectersNoms);
            contrainteNonRespectersListView.setItems(items);
        });
        
        Button modifierAffectationButton = new Button("Modifier un Affectation");
        modifierAffectationButton.setOnAction(e -> modifierAffectation());
        
        Button modifierCreneauButton = new Button("Modifier un Creneau");
        modifierCreneauButton.setOnAction(e -> modifierCreneau());
        
        VBox root = new VBox();
        root.getChildren().addAll(afficherContrainteNonRespectersButton,afficherUneContrainteNonRespectersButton,modifierAffectationButton,modifierCreneauButton,contrainteNonRespectersListView);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);
	}
	

	private List<String> afficherToutesContrainteNonRespecters() {
		ContrainteNonRespecterDAO contrainteNonRespectersDAO = new ContrainteNonRespecterDAO();
		List<String> contrainteNonRespectersInfos = contrainteNonRespectersDAO.afficherToutContrainteNonRespecter().stream()
				.map(contrainteNonRespecters -> contrainteNonRespecters.getId() + " " + contrainteNonRespecters.getContrainte().getTypeValeur()+" Creneau : "+contrainteNonRespecters.getCreneau().getId()+" "+contrainteNonRespecters.getCreneau().getDate()+" "+contrainteNonRespecters.getCreneau().getDebutPlage()+" "+contrainteNonRespecters.getCreneau().getFinPlage() )
				.collect(Collectors.toList());

		return contrainteNonRespectersInfos;
	}
	public List<String> afficherInfosCNR() {
        Formulaire formulaire = new Formulaire(List.of("id"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();
        ContrainteNonRespecterDAO CNRDAO = new ContrainteNonRespecterDAO();
        
        // Initialiser la liste
        List<String> CNRInfos = new ArrayList<>();

        // Récupérer les informations du personnel par ID
        result.ifPresent(values -> {
            if (values.size() == 1) {
                long id = Long.parseLong(values.get(0));
                ContrainteNonRespecter CNR = CNRDAO.afficherContrainteNonRespecter(id);
                if (CNR != null) {
                    
                    Creneau creneau = CNR.getCreneau();
                    Contrainte contrainte = CNR.getContrainte();

                    // Ajouter les informations à la liste
                    CNRInfos.add("Id : " + CNR.getId());
                    CNRInfos.add("ID Creneau : " + creneau.getId());
                    CNRInfos.add("Date Creneau : " + creneau.getDate());
                    CNRInfos.add("Temps Creneau : " + creneau.getDebutPlage()+" "+creneau.getFinPlage());
                    CNRInfos.add(" ID Contrainte : " + contrainte.getId());
                    CNRInfos.add("Contrainte : " + contrainte.getTypeValeur());
                    CNRInfos.add("Valeur Non respecter : " + contrainte.getValeur());
                    
                   
                } else {
                    System.out.println("Personnel non trouvé avec l'ID : " + id);
                }
            }
        });
		return CNRInfos;
    }
	
	private void modifierAffectation() {
        Formulaire formulaire = new Formulaire(List.of("id du Affectation à modifier","creneau","personnel"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 3) {
            	long id = Integer.parseInt(values.get(0));
            	long creneauid = Integer.parseInt(values.get(1));
                long personnelid = Integer.parseInt(values.get(2));
                
                PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
                PersonnelHospitalier personnel = new PersonnelHospitalier();
                personnel = personnelDAO.afficherPersonnelSpecific(personnelid);
	            
                CreneauDAO  CreneauDAO = new  CreneauDAO();
                Creneau  creneau = new  Creneau();
                creneau =  CreneauDAO.afficherUnCreneau(creneauid);
               

                Affectation affectation = new Affectation();
                affectation.setId(id);
                affectation.setCreneau(creneau);
                affectation.setPersonnel(personnel);
                

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                AffectationDAO affectationDAO = new AffectationDAO();
                affectationDAO.update(affectation);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
	
	private void modifierCreneau() {
        Formulaire formulaire = new Formulaire(List.of("id du creneau à modifier","date","debutPlage","finPlage","besoinMinPersonnel","besoinEnSpecialite"));
        Optional<List<String>> result = formulaire.afficherEtAttendre();

        result.ifPresent(values -> {
            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
            if (values.size() == 6) {
            	long id = Integer.parseInt(values.get(0));
            	String date = values.get(1);
                String debutPlage = values.get(2);
                String finPlage = values.get(3);
                int besoinMinPersonnel = Integer.parseInt(values.get(4));
                String besoinEnSpecialite = values.get(5);
               

                Creneau creneau = new Creneau();
                creneau.setId(id);
                creneau.setDate(date);
                creneau.setDebutPlage(debutPlage);
                creneau.setFinPlage(finPlage);
                creneau.setBesoinMinPersonnel(besoinMinPersonnel);
                creneau.setBesoinEnSpecialite(besoinEnSpecialite);

                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
                CreneauDAO creneauDAO = new CreneauDAO();
                creneauDAO.update(creneau);
                
                
            } else {
                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
                System.out.println("Erreur : Nombre de valeurs incorrect.");
            }
        });
    }
	
	
	
	

}
