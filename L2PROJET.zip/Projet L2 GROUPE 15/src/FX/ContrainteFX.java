package FX;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.ContrainteDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Contrainte;

public class ContrainteFX extends Stage{
	
	public ContrainteFX() {
		 
        setTitle("Contrainte");
        
        ListView<String> contraintesListView = new ListView<>();

        Button afficherContraintesButton = new Button("Afficher Toutes les Contrainte");
        afficherContraintesButton.setOnAction(e -> {
            List<String> contraintesInfos = afficherToutesContraintes();
            ObservableList<String> items = FXCollections.observableArrayList(contraintesInfos);
            contraintesListView.setItems(items);
        });

        Button supprimerContrainteButton = new Button("Supprimer Contrainte");
        supprimerContrainteButton.setOnAction(e -> supprimerContrainte());
        
        Button modifierContrainteButton = new Button("Modifier une Contrainte");
        modifierContrainteButton.setOnAction(e -> modifierContrainte());
        
        Button ajouterContraintelButton = new Button("Ajouter Contrainte");
        ajouterContraintelButton.setOnAction(e -> ajouterContrainte());
        
        VBox root = new VBox();
        root.getChildren().addAll(modifierContrainteButton,supprimerContrainteButton,ajouterContraintelButton,afficherContraintesButton,contraintesListView);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);

}
		private List<String> afficherToutesContraintes() {
			ContrainteDAO contrainteDAO = new ContrainteDAO();
			List<String> contrainteInfos = contrainteDAO.afficherToutContrainte().stream()
					.map(contrainte -> contrainte.getId() + " " + contrainte.getTypeValeur())
					.collect(Collectors.toList());

			return contrainteInfos;
 }
	
		private void supprimerContrainte() {
				Formulaire formulaire = new Formulaire(List.of("id"));
				Optional<List<String>> result = formulaire.afficherEtAttendre();

				result.ifPresent(values -> {
            
					if (values.size() == 1) {
						try {
							long id = Long.parseLong(values.get(0));

							// Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
							Contrainte contrainte = new Contrainte();
							ContrainteDAO contrainteDAO = new ContrainteDAO();
							contrainte = contrainteDAO.afficherContrainte(id);
							contrainteDAO.delete(contrainte);

							} catch (NumberFormatException e) {
								System.out.println("Erreur : Format numérique invalide.");
												}

					} else {
						// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
						System.out.println("Erreur : Nombre de valeurs incorrect.");
								}
        });
    }
	
		





		private void ajouterContrainte() {
	        	Formulaire formulaire = new Formulaire(List.of("type de valeur","valeur"));
	        	Optional<List<String>> result = formulaire.afficherEtAttendre();

	        	result.ifPresent(values -> {
	        		// Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	        		if (values.size() == 2) {
	        			String type = values.get(0); 
	        			int valeur = Integer.parseInt(values.get(1));
	        			
	                    Contrainte contrainte = new Contrainte();
	                	contrainte.setTypeValeur(type)   ;
	                	contrainte.setValeur(valeur);
	                	

	                	// Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                	ContrainteDAO contrainteDAO = new ContrainteDAO();
	                	contrainteDAO.create(contrainte);
	                
	                
	        		} else {
	        			// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	        			System.out.println("Erreur : Nombre de valeurs incorrect.");
	        		}
	        	});
			}
	
		




		private void modifierContrainte() {
	        Formulaire formulaire = new Formulaire(List.of("id de la  Contrainte à modifier","type de valeur","valeur"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 3) {
	            	long id = Integer.parseInt(values.get(0));
	            	String type = values.get(1);   
	            	int valeur = Integer.parseInt(values.get(2));

	                Contrainte contrainte = new Contrainte();
	                contrainte.setId(id);
	                contrainte.setTypeValeur(type);  
	                contrainte.setValeur(valeur);
	                

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                ContrainteDAO contrainteDAO = new ContrainteDAO();
	                contrainteDAO.update(contrainte);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	
		
	
}