package FX;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.AffectationDAO;
import DAO.ContrainteNonRespecterDAO;
import DAO.CreneauDAO;
import DAO.PersonnelHospitalierDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Affectation;
import systeme.Creneau;
import systeme.PersonnelHospitalier;

public class AffectationFX extends Stage{
	
	public AffectationFX() {
		 
        setTitle("Affectation");
        
        ListView<String> affectationListView = new ListView<>();

        Button afficherAffectationButton = new Button("Afficher Toutes les Affectation");
        afficherAffectationButton.setOnAction(e -> {
            List<String> affectationNoms = afficherToutesAffectation();
            ObservableList<String> items = FXCollections.observableArrayList(affectationNoms);
            affectationListView.setItems(items);
        });
        
        Button supprimerAffectationButton = new Button("Supprimer Affectation");
        supprimerAffectationButton.setOnAction(e -> supprimerAffectation());
        
        Button modifierAffectationButton = new Button("Modifier un Affectation");
        modifierAffectationButton.setOnAction(e -> modifierAffectation());
        
        Button ajouterAffectationlButton = new Button("Ajouter Affectation");
        ajouterAffectationlButton.setOnAction(e -> ajouterAffectation());
        
        VBox root = new VBox();
        root.getChildren().addAll(modifierAffectationButton,supprimerAffectationButton,ajouterAffectationlButton,afficherAffectationButton,affectationListView);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);

}
		private List<String> afficherToutesAffectation() {
			AffectationDAO affectationDAO = new AffectationDAO();
			List<String> affectationInfos = affectationDAO.afficherToutAffectation().stream()
					.map(affectation -> affectation.getId() + " " + affectation.getPersonnel().getNom()+" "+affectation.getPersonnel().getPrenom()+" "+affectation.getCreneau().getDate()+" "+affectation.getCreneau().getDebutPlage()+" "+affectation.getCreneau().getFinPlage())
					.collect(Collectors.toList());

			return affectationInfos;
}
	
		private void supprimerAffectation() {
				Formulaire formulaire = new Formulaire(List.of("id"));
				Optional<List<String>> result = formulaire.afficherEtAttendre();

				result.ifPresent(values -> {
            
					if (values.size() == 1) {
						try {
							long id = Long.parseLong(values.get(0));

							// Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
							Affectation affectation = new Affectation();
							AffectationDAO affectationDAO = new AffectationDAO();
							affectation = affectationDAO.afficherUneAffectation(id);
							affectationDAO.delete(affectation);

							} catch (NumberFormatException e) {
								System.out.println("Erreur : Format numérique invalide.");
												}

					} else {
						// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
						System.out.println("Erreur : Nombre de valeurs incorrect.");
								}
        });
    }
	
		





		private void ajouterAffectation() {
	        	Formulaire formulaire = new Formulaire(List.of("creneau","personnel"));
	        	Optional<List<String>> result = formulaire.afficherEtAttendre();

	        	result.ifPresent(values -> {
	        		// Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	        		if (values.size() == 2) {
	        			int creneauid = Integer.parseInt(values.get(0));
	        			int personnelid = Integer.parseInt(values.get(1));
	        			
	        			PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
	                    PersonnelHospitalier personnel = new PersonnelHospitalier();
	                    personnel = personnelDAO.afficherPersonnelSpecific(personnelid);
	    	            
	                    CreneauDAO  CreneauDAO = new  CreneauDAO();
	                    Creneau  creneau = new  Creneau();
	                    creneau =  CreneauDAO.afficherUnCreneau(creneauid);
	               

	        			Affectation affectation = new Affectation();
	                	affectation.setCreneau(creneau);
	                	affectation.setPersonnel(personnel);
	                	
	                	
	                	// Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                	AffectationDAO affectationDAO = new AffectationDAO();
	                	if (personnelDAO.respecteContraintes(personnel, creneau)) {
	                				affectationDAO.create(affectation);}
	                	else {
	                		affectationDAO.create(affectation);
	                		afficherFenetreErreur(creneau.getId(),affectation);
	                		
	                	}
	                
	        		} else {
	        			// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	        			System.out.println("Erreur : Nombre de valeurs incorrect.");
	        		}
	        	});
			}
		private void afficherFenetreErreur(long id,Affectation affectation) {
		    Alert alert = new Alert(Alert.AlertType.ERROR);
		    alert.setTitle("Attention");
		    alert.setHeaderText("Contraintes non respectées");
		    ContrainteNonRespecterDAO CNRDAO = new ContrainteNonRespecterDAO();
		    alert.setContentText(CNRDAO.afficherNomContrainte(id));

		    ButtonType boutonContinuer = new ButtonType("Continuer quand même");
		    ButtonType boutonAnnuler = new ButtonType("Annuler");

		    alert.getButtonTypes().setAll(boutonContinuer, boutonAnnuler);

		    // Gérer les actions des boutons
		    alert.showAndWait().ifPresent(response -> {
		        if (response == boutonContinuer) {
		            
		            System.out.println("Continuer quand même");
		        } else if (response == boutonAnnuler) {
		            CNRDAO.delete(CNRDAO.afficherCNR(id));
		            AffectationDAO affectationDAO = new AffectationDAO();
		            affectationDAO.delete(affectation);
		            ajouterAffectation();
		            
		            System.out.println("Annuler");
		        }
		    });
		}
	
		




		private void modifierAffectation() {
	        Formulaire formulaire = new Formulaire(List.of("id du Affectation à modifier","creneau","personnel"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 3) {
	            	long id = Integer.parseInt(values.get(0));
	            	long creneauid = Integer.parseInt(values.get(1));
	                long personnelid = Integer.parseInt(values.get(2));
	                
	                PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
	                PersonnelHospitalier personnel = new PersonnelHospitalier();
	                personnel = personnelDAO.afficherPersonnelSpecific(personnelid);
		            
	                CreneauDAO  CreneauDAO = new  CreneauDAO();
	                Creneau  creneau = new  Creneau();
	                creneau =  CreneauDAO.afficherUnCreneau(creneauid);
	               

	                Affectation affectation = new Affectation();
	                affectation.setId(id);
	                affectation.setCreneau(creneau);
	                affectation.setPersonnel(personnel);
	                

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                AffectationDAO affectationDAO = new AffectationDAO();
	                affectationDAO.update(affectation);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	
		
	
}
