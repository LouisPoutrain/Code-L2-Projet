package FX;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.CadreDeSanteDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.CadreDeSante;

public class CadreDeSanteFX extends Stage{
	
	public CadreDeSanteFX() {
		 
        setTitle("Espace Cadre");
        
        ListView<String> cadreDeSantesListView = new ListView<>();

        Button afficherCadreDeSantesButton = new Button("Afficher Toutes les CadreDeSante");
        afficherCadreDeSantesButton.setOnAction(e -> {
            List<String> cadreDeSantesNoms = afficherToutesCadreDeSantes();
            ObservableList<String> items = FXCollections.observableArrayList(cadreDeSantesNoms);
            cadreDeSantesListView.setItems(items);
        });

        Button supprimerCadreDeSanteButton = new Button("Supprimer CadreDeSante");
        supprimerCadreDeSanteButton.setOnAction(e -> supprimerCadreDeSante());
        
        Button modifierCadreDeSanteButton = new Button("Modifier une CadreDeSante");
        modifierCadreDeSanteButton.setOnAction(e -> modifierCadreDeSante());
        
        Button ajouterCadreDeSantelButton = new Button("Ajouter CadreDeSante");
        ajouterCadreDeSantelButton.setOnAction(e -> ajouterCadreDeSante());
        
        VBox root = new VBox();
        root.getChildren().addAll(modifierCadreDeSanteButton,supprimerCadreDeSanteButton,ajouterCadreDeSantelButton,afficherCadreDeSantesButton,cadreDeSantesListView);

        Scene scene = new Scene(root, 600, 400);
        setScene(scene);

}
		private List<String> afficherToutesCadreDeSantes() {
			CadreDeSanteDAO cadreDeSanteDAO = new CadreDeSanteDAO();
			List<String> cadreDeSantesNoms = cadreDeSanteDAO.afficherToutCadreDeSante().stream()
					.map(cadreDeSante -> cadreDeSante.getId() + " " + cadreDeSante.getNom())
					.collect(Collectors.toList());

			return cadreDeSantesNoms;
 }
	
		private void supprimerCadreDeSante() {
				Formulaire formulaire = new Formulaire(List.of("id"));
				Optional<List<String>> result = formulaire.afficherEtAttendre();

				result.ifPresent(values -> {
            
					if (values.size() == 1) {
						try {
							long id = Long.parseLong(values.get(0));

							// Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
							CadreDeSante cadreDeSante = new CadreDeSante();
							CadreDeSanteDAO cadreDeSanteDAO = new CadreDeSanteDAO();
							cadreDeSante = cadreDeSanteDAO.afficherUnCadreDeSante(id);
							cadreDeSanteDAO.delete(cadreDeSante);

							} catch (NumberFormatException e) {
								System.out.println("Erreur : Format numérique invalide.");
												}

					} else {
						// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
						System.out.println("Erreur : Nombre de valeurs incorrect.");
								}
        });
    }
	
		





		private void ajouterCadreDeSante() {
	        	Formulaire formulaire = new Formulaire(List.of("nom","prenom","mot de passe"));
	        	Optional<List<String>> result = formulaire.afficherEtAttendre();

	        	result.ifPresent(values -> {
	        		// Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	        		if (values.size() == 3) {
	        			String nom = values.get(0); 
	        			String prenom = values.get(1);
	        			String mdp = values.get(2);
	        			
	                    CadreDeSante cadreDeSante = new CadreDeSante();
	                	cadreDeSante.setNom(nom); 
	                	cadreDeSante.setPrenom(prenom);
	                	cadreDeSante.setMotdepasse(mdp);
	                	

	                	// Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                	CadreDeSanteDAO cadreDeSanteDAO = new CadreDeSanteDAO();
	                	cadreDeSanteDAO.create(cadreDeSante);
	                
	                
	        		} else {
	        			// Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	        			System.out.println("Erreur : Nombre de valeurs incorrect.");
	        		}
	        	});
			}
	
		




		private void modifierCadreDeSante() {
	        Formulaire formulaire = new Formulaire(List.of("id de la  CadreDeSante à modifier","nom","prenom","Mot De Passe"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 4) {
	            	long id = Integer.parseInt(values.get(0));
	            	String nom = values.get(1); 
	            	String prenom = values.get(2);
	            	String mdp = values.get(3);
	            	

	                CadreDeSante cadreDeSante = new CadreDeSante();
	                cadreDeSante.setId(id);
	                cadreDeSante.setNom(nom); 
	                cadreDeSante.setPrenom(prenom);
	                cadreDeSante.setMotdepasse(mdp);
	                

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                CadreDeSanteDAO cadreDeSanteDAO = new CadreDeSanteDAO();
	                cadreDeSanteDAO.update(cadreDeSante);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	
		
	
}

