package FX;

import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.scene.control.Label;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Formulaire extends Dialog<List<String>> {
    private List<TextField> textFields = new ArrayList<>();

    public Formulaire(List<String> titres) {
        initModality(Modality.APPLICATION_MODAL);

        ButtonType okButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

        VBox content = new VBox();

        for (int i = 0; i < titres.size(); i++) {
            Label label = new Label(titres.get(i) + ": ");
            TextField textField = new TextField();
            textFields.add(textField);

            // Créer une boîte horizontale pour chaque paire Label-TextField
            HBox pair = new HBox();
            pair.getChildren().addAll(label, textField);

            // Ajouter la boîte horizontale à la boîte verticale principale
            content.getChildren().add(pair);
        }

        getDialogPane().setContent(content);

        setResultConverter(buttonType -> {
            if (buttonType == okButtonType) {
                List<String> result = new ArrayList<>();
                for (TextField textField : textFields) {
                    result.add(textField.getText());
                }
                return result;
            }
            return null;
        });
    }

    public Optional<List<String>> afficherEtAttendre() {
        return showAndWait();
    }
}

