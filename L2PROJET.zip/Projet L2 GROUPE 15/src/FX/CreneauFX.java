package FX;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import DAO.CreneauDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import systeme.Creneau;
import systeme.PersonnelHospitalier;

public class CreneauFX extends Stage{

	 public CreneauFX() {
		 
	        setTitle("Creneau");

	        ListView<String> creneaulListView1 = new ListView<>();
	       

	        Button afficherCreneauButton = new Button("Afficher Tout les Creneau");
	        afficherCreneauButton.setOnAction(e -> {
	            List<String> creneauInfos = afficherToutCreneau();
	            ObservableList<String> items = FXCollections.observableArrayList(creneauInfos);
	            creneaulListView1.setItems(items);
	        });
	        
	        Button supprimerCreneauButton = new Button("Supprimer Creneau");
	        supprimerCreneauButton.setOnAction(e -> supprimerCreneau());
	        
	        Button modifierCreneauButton = new Button("Modifier un Creneau");
	        modifierCreneauButton.setOnAction(e -> modifierCreneau());
	        
	        Button ajouterCreneaulButton = new Button("Ajouter Creneau");
	        ajouterCreneaulButton.setOnAction(e -> ajouterCreneau());
	        
	        Button afficherInfosCreneau = new Button("Afficher Infos Creneau");
	        afficherInfosCreneau.setOnAction(e ->  {
	            List<String> creneauInfos = afficherInfosCreneau();
	            ObservableList<String> items = FXCollections.observableArrayList(creneauInfos);
	            creneaulListView1.setItems(items);
	        });
	        Button afficherListPersonnelCreneau = new Button("Afficher  Liste Personnel Creneau");
	        afficherListPersonnelCreneau.setOnAction(e ->  {
	            List<String> creneauInfos = afficherListPersonnel();
	            ObservableList<String> items = FXCollections.observableArrayList(creneauInfos);
	            creneaulListView1.setItems(items);
	        });
	        
	        
	        VBox root = new VBox();
	        root.getChildren().addAll(afficherCreneauButton,afficherListPersonnelCreneau, supprimerCreneauButton,modifierCreneauButton,ajouterCreneaulButton,afficherInfosCreneau,creneaulListView1);

	        Scene scene = new Scene(root, 600, 400);
	        setScene(scene);
	    }

	    private List<String> afficherToutCreneau() {
	        CreneauDAO creneauDAO = new CreneauDAO();
	        List<String> creneauInfo = creneauDAO.afficherToutLesCreneau().stream()
	                .map(creneau -> creneau.getId() + " " + creneau.getDate()+" "+creneau.getDebutPlage()+" "+creneau.getFinPlage())
	                .collect(Collectors.toList());
	        return creneauInfo;
	    }
	    
	    private void supprimerCreneau() {
	        Formulaire formulaire = new Formulaire(List.of("id"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            
	            if (values.size() == 1) {
	                try {
	                    long id = Long.parseLong(values.get(0));

	                    // Utiliser PersonnelHospitalierDAO pour supprimer le personnel dans la base de données
	                    Creneau creneau = new Creneau();
	                    CreneauDAO creneauDAO = new CreneauDAO();
	                    creneau = creneauDAO.afficherUnCreneau(id);
	                    creneauDAO.delete(creneau);

	                } catch (NumberFormatException e) {
	                    System.out.println("Erreur : Format numérique invalide.");
	                }

	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }


	    private void ajouterCreneau() {
	        Formulaire formulaire = new Formulaire(List.of("date","debutPlage","finPlage","besoinMinPersonnel","besoinEnSpecialite"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 5) {
	                String date = values.get(0);
	                String debutPlage = values.get(1);
	                String finPlage = values.get(2);
	                int besoinMinPersonnel = Integer.parseInt(values.get(3));
	                String besoinEnSpecialite = values.get(4);
	                
	               

	                Creneau creneau = new Creneau();
	                creneau.setDate(date);
	                creneau.setDebutPlage(debutPlage);
	                creneau.setFinPlage(finPlage);
	                creneau.setBesoinMinPersonnel(besoinMinPersonnel);
	                creneau.setBesoinEnSpecialite(besoinEnSpecialite);

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                CreneauDAO creneauDAO = new CreneauDAO();
	                creneauDAO.create(creneau);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	    
	    private void modifierCreneau() {
	        Formulaire formulaire = new Formulaire(List.of("id du creneau à modifier","date","debutPlage","finPlage","besoinMinPersonnel","besoinEnSpecialite"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();

	        result.ifPresent(values -> {
	            // Créer une nouvelle instance de Specialite avec les valeurs du formulaire
	            if (values.size() == 6) {
	            	long id = Integer.parseInt(values.get(0));
	            	String date = values.get(1);
	                String debutPlage = values.get(2);
	                String finPlage = values.get(3);
	                int besoinMinPersonnel = Integer.parseInt(values.get(4));
	                String besoinEnSpecialite = values.get(5);
	               

	                Creneau creneau = new Creneau();
	                creneau.setId(id);
	                creneau.setDate(date);
	                creneau.setDebutPlage(debutPlage);
	                creneau.setFinPlage(finPlage);
	                creneau.setBesoinMinPersonnel(besoinMinPersonnel);
	                creneau.setBesoinEnSpecialite(besoinEnSpecialite);

	                // Utiliser SpecialiteDAO pour créer la nouvelle spécialité dans la base de données
	                CreneauDAO creneauDAO = new CreneauDAO();
	                creneauDAO.update(creneau);
	                
	                
	            } else {
	                // Gérer l'erreur si le nombre de valeurs n'est pas celui attendu
	                System.out.println("Erreur : Nombre de valeurs incorrect.");
	            }
	        });
	    }
	    
	    public List<String> afficherInfosCreneau() {
	        Formulaire formulaire = new Formulaire(List.of("id"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();
	        CreneauDAO creneauDAO = new CreneauDAO();
	        
	        // Initialiser la liste
	        List<String> creneauInfos = new ArrayList<>();

	        // Récupérer les informations du personnel par ID
	        result.ifPresent(values -> {
	            if (values.size() == 1) {
	                long id = Long.parseLong(values.get(0));
	                Creneau creneau = creneauDAO.afficherUnCreneau(id);
	                if (creneau != null) {
	                  
	                	// Ajouter les informations à la liste
	                    creneauInfos.add("Id : " + creneau.getId());
	                    creneauInfos.add("Date : " + creneau.getDate());
	                    creneauInfos.add("Debut Plage : " + creneau.getDebutPlage());
	                    creneauInfos.add("Fin Plage : " + creneau.getFinPlage());
	                    creneauInfos.add("Besoin en personnel  : " + creneau.getBesoinMinPersonnel());
	                    creneauInfos.add("Besoin en Specialite : " + creneau.getBesoinEnSpecialite());
	                    
	                   
	                } else {
	                    System.out.println("Creneau non trouvé avec l'ID : " + id);
	                }
	            }
	        });
			return creneauInfos;
	    }

	    public List<String> afficherListPersonnel() {
	        Formulaire formulaire = new Formulaire(List.of("id"));
	        Optional<List<String>> result = formulaire.afficherEtAttendre();
	        CreneauDAO creneauDAO = new CreneauDAO();
	        
	        // Initialiser la liste
	        List<String> LP = new ArrayList<>();

	        // Récupérer les informations du personnel par ID
	        result.ifPresent(values -> {
	            if (values.size() == 1) {
	                List<PersonnelHospitalier> lp = creneauDAO.afficherListePersonnel(Long.parseLong(values.get(0)));
	                for (int i = 0; i <lp.size() ; i++) {
	                	LP.add("id : "+lp.get(i).getId()+" Nom : "+lp.get(i).getNom()+" Prenom : "+lp.get(i).getPrenom());                		
	                	}
	                } 
	        	});	        
			return LP;
	    } 
	    
	  }
