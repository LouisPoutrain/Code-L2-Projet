package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Affectation;
import systeme.Creneau;
import systeme.PersonnelHospitalier;


public class AffectationDAO extends DAO<Affectation> {
	
	ResultSet rs;
	
	@Override
	public Affectation create(Affectation affectation) {
		String requete = "INSERT INTO affectation  (creneau,personnel) "
				+ "VALUES('" + affectation.getCreneau().getId()+ "', '"+ affectation.getPersonnel().getId()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				affectation.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return affectation;
	}


	@Override
	public Affectation update(Affectation affectation) {
		String requete = "UPDATE affectation  SET creneau ='" + affectation.getCreneau().getId()+"', ";
		requete +="personnel= '"+ affectation.getPersonnel().getId()+ "' ";
		requete +="WHERE idAffectation = " + affectation.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return affectation;

		}

	@Override
	public void delete(Affectation affectation) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM affectation WHERE idAffectation = " + affectation.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Affectation afficherUneAffectation(long id) {
	    String query = "SELECT * FROM affectation WHERE idAffectation = " + id;

	    
		try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	long id1 = rs.getLong("idAffectation");
	            int creneauid = rs.getInt("creneau");
	            int personnelid = rs.getInt("personnel");
	            
	            PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
                PersonnelHospitalier personnel = new PersonnelHospitalier();
                personnel = personnelDAO.afficherPersonnelSpecific(personnelid);
	            
                CreneauDAO  CreneauDAO = new  CreneauDAO();
                Creneau  creneau = new  Creneau();
                creneau =  CreneauDAO.afficherUnCreneau(creneauid);
                
	            return new Affectation(id1,creneau,personnel);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	public List<Affectation> afficherToutAffectation() {
	    List<Affectation> affectationListe = new ArrayList<>();
	    String query = "SELECT * FROM affectation";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	 long id = rs.getLong("idAffectation");
		            int creneauid = rs.getInt("creneau");
		            int personnelid = rs.getInt("personnel");
		            
		            PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
	                PersonnelHospitalier personnel = new PersonnelHospitalier();
	                personnel = personnelDAO.afficherPersonnelSpecific(personnelid);
		            
	                CreneauDAO  CreneauDAO = new  CreneauDAO();
	                Creneau  creneau = new  Creneau();
	                creneau =  CreneauDAO.afficherUnCreneau(creneauid);

	            Affectation affectation =new Affectation(id,creneau,personnel);
	            affectationListe.add(affectation);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	return affectationListe;
	}
	
	

}
