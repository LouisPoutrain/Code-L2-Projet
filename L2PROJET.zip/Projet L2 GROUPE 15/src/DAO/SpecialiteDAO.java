package DAO;


import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import systeme.Specialite;


public class SpecialiteDAO extends DAO<Specialite> {
	
	private ResultSet rs;
	
	@Override
	public Specialite create(Specialite specialite) {
		String requete = "INSERT INTO specialité  (nom,TempsMax) "
				+ "VALUES('" + specialite.getNom()+ "', '"+ specialite.getTempsMax()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				specialite.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return specialite;
	}


	@Override
	public Specialite update(Specialite specialite) {
		String requete = "UPDATE specialité  SET nom ='" + specialite.getNom()+"', ";
		requete +="TempsMax= '"+ specialite.getTempsMax()+ "' ";
		requete +="WHERE idSpecialité = " + specialite.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return specialite;

		}

	@Override
	public void delete(Specialite specialite) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM specialité WHERE idSpecialité = " + specialite.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Specialite afficherUneSpecialite(long idSpecialite) {
	    String query = "SELECT * FROM specialité WHERE idSpecialité = " + idSpecialite;

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	            long id = rs.getLong("idSpecialité");
	            String nom = rs.getString("nom");
	            int TempsMax = rs.getInt("TempsMax");
	           

	            return new Specialite(id,nom,TempsMax);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	
	public List<Specialite> afficherToutSpecialite() {
	    List<Specialite> specialiteListe = new ArrayList<>();
	    String query = "SELECT * FROM specialité";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	long id = rs.getLong("idSpecialité");
	            String nom = rs.getString("nom");
	            int TempsMax = rs.getInt("TempsMax");

	            Specialite specialite1=new Specialite(id, nom,TempsMax);
	            specialiteListe.add(specialite1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return specialiteListe;
	}
	
	public Specialite afficherUneSpecialiteNom(String nom) {
	    String query = "SELECT * FROM specialité WHERE nom = '" + nom + "'";
	    Specialite specialite = null;
	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.first()) {
	             specialite = new Specialite(rs.getLong("idSpecialité"), rs.getString("nom"), rs.getInt("TempsMax"));
	        }

	        rs.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return specialite;
	}
	
	
	
}