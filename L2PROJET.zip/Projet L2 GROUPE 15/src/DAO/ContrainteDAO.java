package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Contrainte;


public class ContrainteDAO extends DAO<Contrainte> {
	
	private ResultSet rs;
	
	@Override
	public Contrainte create(Contrainte CL) {
		String requete = "INSERT INTO contrainte  (type,valeur) "
				+ "VALUES('" + CL.getTypeValeur()+ "', '"+ CL.getValeur()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				CL.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return CL;
	}


	@Override
	public Contrainte update(Contrainte CL) {
		String requete = "UPDATE contrainte  SET type ='" + CL.getTypeValeur()+"', ";
		requete +="valeur= '"+ CL.getValeur()+ "' ";
		requete +="WHERE idContrainte = " + CL.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return CL;

		}

	@Override
	public void delete(Contrainte CL) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM contrainte WHERE idContrainte = " + CL.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Contrainte afficherContrainte(long idContrainte) {
	    String query = "SELECT * FROM contrainte WHERE idContrainte = " + idContrainte;

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	            long id = rs.getLong("idContrainte");
	            String type = rs.getString("type");
	            int valeur = rs.getInt("valeur");
	            ;

	            return new Contrainte(id,type,valeur);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	public List<Contrainte> afficherToutContrainte() {

	    List<Contrainte> contrainteListe = new ArrayList<>();
	    String query = "SELECT * FROM contrainte";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	 long id = rs.getLong("idContrainte");
		            String type = rs.getString("type");
		            int valeur = rs.getInt("valeur");

	            Contrainte contrainte1=new Contrainte(id,type,valeur);
	            contrainteListe.add(contrainte1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	return contrainteListe;
	}
	
	public List<Contrainte> listeContrainteFonction(long id){
		List<Contrainte> contrainteListe = new ArrayList<>();
	    String query = "SELECT * FROM contrainte WHERE fonction = "+id;
	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	 long id1 = rs.getLong("idContrainte");
		            String type = rs.getString("type");
		            int valeur = rs.getInt("valeur");

	            Contrainte contrainte1=new Contrainte(id1,type,valeur);
	            contrainteListe.add(contrainte1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	return contrainteListe;
	}

}
	
