package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Creneau;
import systeme.PersonnelHospitalier;


public class CreneauDAO extends DAO<Creneau> {
	
	private ResultSet rs;
	
	@Override
	public Creneau create(Creneau creneau) {
		String requete = "INSERT INTO creneau  (date,debutPlage,finPlage,besoinMinPersonnel,besoinEnSpecialite) "
				+ "VALUES('" + creneau.getDate()+ "', '"+ creneau.getDebutPlage()+ "', '" +creneau.getFinPlage()+"','"+creneau.getBesoinMinPersonnel()+"','"+creneau.getBesoinEnSpecialite()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				creneau.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return creneau;
	}


	@Override
	public Creneau update(Creneau creneau) {
		String requete = "UPDATE creneau  SET date ='" + creneau.getDate()+"', ";
		requete +="debutPlage= '"+ creneau.getDebutPlage()+ "', ";
		requete += "finPlage= '"+ creneau.getFinPlage()+ "', ";
		requete += "besoinMinPersonnel= '"+ creneau.getBesoinMinPersonnel()+ "', ";
		requete += "besoinEnSpecialite= '"+ creneau.getBesoinEnSpecialite()+ "' ";
		requete +="WHERE idCreneau = " + creneau.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return creneau;

		}

	@Override
	public void delete(Creneau creneau) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM creneau WHERE idCreneau = " + creneau.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Creneau afficherUnCreneau(long idCreneau) {
	    String query = "SELECT * FROM creneau WHERE idCreneau = " + idCreneau;

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	long id = rs.getLong("idCreneau");
	            String date = rs.getString("date");
	            String debutPlage = rs.getString("debutPlage");
	            String  finPlage = rs.getString("finPlage");
	            int besoinMinPersonnel = rs.getInt("besoinMinpersonnel");
	            String besoinEnSpecialite = rs.getString("besoinEnSpecialite");

	            return new Creneau(id,date,debutPlage,finPlage,besoinMinPersonnel,besoinEnSpecialite);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	
	public List<Creneau> afficherToutLesCreneau() {
	    List<Creneau> creneauList = new ArrayList<>();
	    String query = "SELECT * FROM creneau";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	long id = rs.getLong("idCreneau");
	            String date = rs.getString("date");
	            String debutPlage = rs.getString("debutPlage");
	            String  finPlage = rs.getString("finPlage");
	            int besoinMinPersonnel = rs.getInt("besoinMinpersonnel");
	            String besoinEnSpecialite = rs.getString("besoinEnSpecialite");
	            
	            
	            Creneau creneau = new Creneau(id,date,debutPlage,finPlage,besoinMinPersonnel,besoinEnSpecialite) ;
	            creneauList.add(creneau);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return creneauList;
	}
	
	public List<PersonnelHospitalier> afficherListePersonnel(long idCreneau) {
		List<PersonnelHospitalier> personnelList = new ArrayList<>();
	    String query = "SELECT personnel FROM affectation WHERE affectation.creneau="+idCreneau;

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	
	        	PersonnelHospitalierDAO personnelDAO = new PersonnelHospitalierDAO();
	            PersonnelHospitalier personnel = personnelDAO.afficherPersonnelSpecific(rs.getLong("personnel"));
	            personnelList.add(personnel);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return personnelList;
	}
	
	public float nombreHeuresCreneau(long id) {
		float n=0;
		String query = "SELECT TIME_TO_SEC( TIMEDIFF( finPlage, debutPlage ) ) /3600 AS durée FROM creneau WHERE idCreneau = "+id ;
		try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	n = rs.getFloat("durée");
	        	return n;
	        	
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
		return n;

	    
	}
	

}
