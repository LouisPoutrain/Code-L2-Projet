package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Contrainte;
import systeme.ContrainteNonRespecter;
import systeme.Creneau;
import systeme.Fonction;
import systeme.PersonnelHospitalier;
import systeme.Specialite;

public class PersonnelHospitalierDAO extends DAO<PersonnelHospitalier> {
	
	private ResultSet rs;
	
	@Override
	public PersonnelHospitalier create(PersonnelHospitalier unPersonnel) {
		String requete = "INSERT INTO personnel  (nom, prénom, specialité, TempsTravailleMensuel,fonction) "
				+ "VALUES('" + unPersonnel.getNom()+ "', '"+ unPersonnel.getPrenom()+ "', '" +unPersonnel.getSpecialite().getId()+"','"+unPersonnel.getTpstravailmensuel()+"','"+unPersonnel.getFonction().getId()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				unPersonnel.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return unPersonnel;
	}


	@Override
	public PersonnelHospitalier update(PersonnelHospitalier unPersonnel) {
		String requete = "UPDATE personnel  SET nom ='" + unPersonnel.getNom()+"', ";
		requete +="prénom= '"+ unPersonnel.getPrenom()+ "', ";
		requete += "fonction= '"+ unPersonnel.getFonction().getId()+ "', ";
		requete += "specialité= '"+ unPersonnel.getSpecialite().getId()+ "', ";
		requete += "TempsTravailleMensuel= '"+ unPersonnel.getTpstravailmensuel()+ "' ";		
		requete +="WHERE idPersonnel = " + unPersonnel.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return unPersonnel;

		}

	@Override
	public void delete(PersonnelHospitalier unPersonnel) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM personnel WHERE idPersonnel = " + unPersonnel.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public PersonnelHospitalier afficherPersonnelSpecific(long personnelId) {
	    String query = "SELECT * FROM personnel WHERE idPersonnel = " + personnelId;

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	long id = rs.getLong("idPersonnel");
	            String nom = rs.getString("nom");
	            String prenom = rs.getString("prénom");
	            FonctionDAO fonctionDAO = new FonctionDAO();
                Fonction fonction = new Fonction();
                fonction = fonctionDAO.afficherUneFonction(rs.getInt("fonction"));
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                Specialite specialite = new Specialite();
                specialite = specialiteDAO.afficherUneSpecialite(rs.getInt("specialité"));
	            float tpstravailmensuel = rs.getFloat("TempsTravailleMensuel");

	            return new PersonnelHospitalier(id, nom, prenom, fonction, specialite, tpstravailmensuel);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	
	
	public List<PersonnelHospitalier> afficherToutPersonnel() {
	    List<PersonnelHospitalier> personnelList = new ArrayList<>();
	    String query = "SELECT * FROM personnel";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	            long id = rs.getLong("idPersonnel");
	            String nom = rs.getString("nom");
	            String prenom = rs.getString("prénom");
	            FonctionDAO fonctionDAO = new FonctionDAO();
                Fonction fonction = new Fonction();
                fonction = fonctionDAO.afficherUneFonction(rs.getInt("fonction"));
                SpecialiteDAO specialiteDAO = new SpecialiteDAO();
                Specialite specialite = new Specialite();
                specialite = specialiteDAO.afficherUneSpecialite(rs.getInt("specialité"));
	            float tpstravailmensuel = rs.getFloat("TempsTravailleMensuel");

	            PersonnelHospitalier personnel = new PersonnelHospitalier(id, nom, prenom, fonction, specialite, tpstravailmensuel);
	            personnelList.add(personnel);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return personnelList;
	}
	
	public List<Creneau> afficherEmploieDuTempsDunPersonnel(long personnelId) {
	    List<Creneau> creneauList = new ArrayList<>();
	    String query = "SELECT creneau.idCreneau FROM affectation JOIN creneau ON affectation.creneau = creneau.idCreneau WHERE affectation.personnel ="
	    				+personnelId+ " ORDER BY creneau.debutPlage";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	            long id = rs.getLong("idCreneau");
	            
	            
	            CreneauDAO creneauDAO = new CreneauDAO();
	            Creneau creneau = creneauDAO.afficherUnCreneau(id) ;
	            creneauList.add(creneau);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return creneauList;
	}
	
	public float nombreDheurePlanifier(long id) {
		float n = 0 ;
		String query = "SELECT SUM( TIME_TO_SEC( TIMEDIFF( c.finPlage, c.debutPlage ) ) ) /3600 AS total "
				+ " FROM personnel p"
				+ " JOIN affectation a ON p.idPersonnel = a.personnel"
				+ " JOIN creneau c ON a.creneau = c.IdCreneau"
				+ " WHERE p.idPersonnel ="+ id ;
		 
		try {
		        rs = stmt.executeQuery(query);

		        
		        while (rs.next()) {
		             n = rs.getFloat("total");
		
		
		        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return n;
	}
	
	public float reposQuotidien(long id, String date) {
	    float n = 1000000;
	    
	    String query = "SELECT p.idPersonnel, (24 - HOUR(MAX(c1.finPlage))) + HOUR(MIN(c2.debutPlage)) AS tempsRepos " +
	            "FROM personnel p " +
	            "JOIN affectation a1 ON p.idPersonnel = a1.personnel " +
	            "JOIN creneau c1 ON a1.creneau = c1.IdCreneau " +
	            "JOIN affectation a2 ON p.idPersonnel = a2.personnel " +
	            "JOIN creneau c2 ON a2.creneau = c2.IdCreneau " +
	            "WHERE p.idPersonnel =" + id + " AND c1.date = '" + date + "' AND c2.date = DATE_ADD( '" + date + "' , INTERVAL 1 DAY)";
	    
	    try {
	        rs = stmt.executeQuery(query);
	        
	        while (rs.next()) {
	            if (rs.getFloat("tempsRepos") != 0.0) {
	                n = rs.getFloat("tempsRepos");
	                
	                return n;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    return n;
	}

	
	public boolean respecteContraintes(PersonnelHospitalier personnel,Creneau creneau) {
		boolean b = true;
		CreneauDAO creneauDAO = new CreneauDAO();
		ContrainteDAO contrainteDAO = new ContrainteDAO();
		ContrainteNonRespecterDAO contrainteNonRespecterDAO = new ContrainteNonRespecterDAO();
		float nombreHeure = nombreDheurePlanifier(personnel.getId())+ creneauDAO.nombreHeuresCreneau(creneau.getId());
		float heureReposQuotidien = reposQuotidien(personnel.getId(),creneau.getDate());
		
		if (nombreHeure>personnel.getTpstravailmensuel()) {
			Contrainte contrainte = new Contrainte((long)0,"Temps Maximal Du Personnel Dépasser",(int)personnel.getTpstravailmensuel());
			contrainteDAO.create(contrainte);
			System.out.println(nombreHeure);
			ContrainteNonRespecter cnr = new ContrainteNonRespecter((long)0,creneau,contrainte);
			contrainteNonRespecterDAO.create(cnr);
			System.out.println(nombreHeure);
			return false;
		}
		 if (heureReposQuotidien < contrainteDAO.afficherContrainte(1).getValeur()) {
			contrainteNonRespecterDAO.create(new ContrainteNonRespecter((long)0,creneau,contrainteDAO.afficherContrainte(1)));
			
			
			return false;
		 }
		return b;
		
		
	}
}
