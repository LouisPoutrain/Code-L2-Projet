package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public abstract class DAO<T> {

	protected Connection connect;
	protected Statement stmt;

	public DAO (){
		open();
	}

	public void open() {
		try {
			connect=  SingleConnection.getInstance();
			stmt = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(" === ERREUR OPEN DAO === ");
			e.printStackTrace();
		}
		
	}
	
	public void close(){
		try {
			SingleConnection.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(" === ERREUR CLOSE DAO === ");
			e.printStackTrace();
		}
	}
	
	/**
	 * Permet de r�cup�rer les objets
	 * @param
	 * @return
	 */
//	public abstract ArrayList <T> read();
	
	/**
	 * Permet de cr�er une entr�e dans la base de donn�es
	 * par rapport � un objet
	 * @param obj
	 */
	public abstract T create(T obj);
	
	/**
	 * Permet de mettre � jour les donn�es d'une entr�e dans la base 
	 * @param obj
	 */
	public abstract T update(T obj);
	
	/**
	 * Permet la suppression d'une entr�e de la base
	 * @param obj
	 */
	public abstract void delete(T obj);
}

