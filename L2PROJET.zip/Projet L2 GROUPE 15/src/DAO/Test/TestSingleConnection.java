package DAO.Test;

	import DAO.SingleConnection;

	import java.sql.Connection;
	import java.sql.SQLException;

	public class TestSingleConnection {

	    public static void main(String[] args) {
	        testSingleConnection();
	 
	    }

	    private static void testSingleConnection() {
	        try {
	            
	            Connection connection = SingleConnection.getInstance();
	            System.out.println("SingleConnection Test: Connection obtained successfully.");

	            
	            SingleConnection.close();
	            System.out.println("SingleConnection Test: Connection closed successfully.");
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	            System.out.println("SingleConnection Test: Error occurred during the test.");
	        }
	    }
}
