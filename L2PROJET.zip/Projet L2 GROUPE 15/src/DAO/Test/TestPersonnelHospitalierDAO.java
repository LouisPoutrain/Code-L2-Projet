package DAO.Test;


public class TestPersonnelHospitalierDAO {
}

