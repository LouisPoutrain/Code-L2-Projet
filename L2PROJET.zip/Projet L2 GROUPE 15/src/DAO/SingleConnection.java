package DAO;

import java.sql.Connection;
import java.sql.SQLException;

import com.mysql.cj.jdbc.MysqlDataSource;

public class SingleConnection {

	private static Connection connect;

	
	private SingleConnection(String serverName, String dbName, String login, String password) throws ClassNotFoundException, SQLException{
		
		String url="jdbc:mysql://"+serverName+":3307/"+dbName+"?serverTimezone=UTC";

		MysqlDataSource mysqlDS = new MysqlDataSource();
		mysqlDS.setURL(url);
		mysqlDS.setUser(login);
		mysqlDS.setPassword(password);

		connect = mysqlDS.getConnection();
	}
	
	public static Connection getInstance(String serverName, String dbName, String login, String password) throws ClassNotFoundException, SQLException{
		if(connect == null){  
			new SingleConnection(serverName, dbName, login, password);
		}
		return connect;   
	}
	
	public static Connection getInstance() throws ClassNotFoundException, SQLException{
		if(connect == null){  
			new SingleConnection("localhost", "l2projet", "root", "usbw");
		}
		return connect; 
	}
	
	public static void close() {
		try {
			connect.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
