package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Contrainte;
import systeme.ContrainteNonRespecter;
import systeme.Creneau;


public class ContrainteNonRespecterDAO extends DAO<ContrainteNonRespecter> {
	
	private ResultSet rs;
	
	@Override
	public ContrainteNonRespecter create(ContrainteNonRespecter CNR) {
		String requete = "INSERT INTO contrainteNonRespecter  (creneau,contrainte) "
				+ "VALUES('" + CNR.getCreneau().getId()+ "', '"+ CNR.getContrainte().getId()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				CNR.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return CNR;
	}


	@Override
	public ContrainteNonRespecter update(ContrainteNonRespecter CNR) {
		String requete = "UPDATE contrainteNonRespecter  SET creneau ='" + CNR.getCreneau()+"', ";
		requete +="contrainte= '"+ CNR.getContrainte()+ "', ";
		requete +="WHERE idContrainteNonRespecter = " + CNR.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return CNR;

		}

	@Override
	public void delete(ContrainteNonRespecter CNR) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM contrainteNonRespecter WHERE idContrainteNonRespecter = " + CNR.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ContrainteNonRespecter afficherContrainteNonRespecter(long idContrainteNonRespecter) {
	    String query = "SELECT * FROM contrainteNonRespecter WHERE idContrainteNonRespecter = " + idContrainteNonRespecter;

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	            long id = rs.getLong("idContrainteNonRespecter");
	            long creneauid = rs.getLong("creneau");
	            long contrainteid = rs.getLong("contrainte");
	            ;
	            CreneauDAO creneauDAO = new CreneauDAO();
	            Creneau creneau = creneauDAO.afficherUnCreneau(creneauid);
	            
	            ContrainteDAO contrainteDAO = new ContrainteDAO();
	            Contrainte contrainte =contrainteDAO.afficherContrainte(contrainteid);
	            
	            return new ContrainteNonRespecter(id,creneau,contrainte);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; 
	}
	
	public List<ContrainteNonRespecter> afficherToutContrainteNonRespecter() {
	    String query = "SELECT * FROM contrainteNonRespecter ";
	    List<ContrainteNonRespecter> CNRListe = new ArrayList<>();

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	long id = rs.getLong("idContrainteNonRespecter");
	            long creneauid = rs.getLong("creneau");
	            long contrainteid = rs.getLong("contrainte");
	            ;
	            CreneauDAO creneauDAO = new CreneauDAO();
	            Creneau creneau = creneauDAO.afficherUnCreneau(creneauid);
	            
	            ContrainteDAO contrainteDAO = new ContrainteDAO();
	            Contrainte contrainte =contrainteDAO.afficherContrainte(contrainteid);

	            ContrainteNonRespecter contrainteNonRespecter1 = new ContrainteNonRespecter(id,creneau,contrainte);
	            CNRListe.add(contrainteNonRespecter1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return CNRListe; 
	}
	
	public String afficherNomContrainte(long id){
	    String query = "SELECT  c.type AS contrainteD\r\n"
	    		+ "FROM contraintenonrespecter cnr\r\n"
	    		+ "JOIN contrainte c ON cnr.contrainte = c.idContrainte\r\n"
	    		+ "WHERE cnr.creneau = "+id;
	    

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	String contrainte = rs.getString("contrainteD");
	            return contrainte;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    String contrainte = "";
		return contrainte ; 
	}
	public ContrainteNonRespecter afficherCNR(long id){
		ContrainteNonRespecter CNR = new ContrainteNonRespecter();
	    String query = "SELECT  cnr.idContrainteNonRespecter\r\n"
	    		+ "FROM contraintenonrespecter cnr\r\n"
	    		+ "JOIN contrainte c ON cnr.contrainte = c.idContrainte\r\n"
	    		+ "WHERE cnr.creneau = "+id;
	    

	    try {
	        rs = stmt.executeQuery(query);

	        if (rs.next()) {
	        	long CNRid = rs.getLong("idContrainteNonRespecter");
	        	ContrainteNonRespecterDAO CNRDAO = new ContrainteNonRespecterDAO();
	        	ContrainteNonRespecter CNR1 = CNRDAO.afficherContrainteNonRespecter(CNRid);
	            return CNR1;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    
		return CNR ; 
	}
}
