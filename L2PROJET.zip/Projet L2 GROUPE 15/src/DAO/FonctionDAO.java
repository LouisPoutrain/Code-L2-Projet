package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.Fonction;

public class FonctionDAO extends DAO<Fonction> {

	private ResultSet rs;

	
	public Fonction create(Fonction fonction) {
		String requete = "INSERT INTO fonction  (nom) "
				+ "VALUES('" + fonction.getNom()+ "')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				fonction.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return fonction;
	}


	@Override
	public Fonction update(Fonction fonction) {
		// TODO Auto-generated method stub
		String requete = "UPDATE fonction  SET nom ='" + fonction.getNom()+"'WHERE idFonction='"+fonction.getId()+"'";
		
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fonction;

		}

	@Override
	public void delete(Fonction fonction) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM fonction WHERE idFonction = " + fonction.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Fonction afficherUneFonction(long id) {
		String requete = "SELECT * FROM fonction WHERE idFonction = " + id;
		Fonction fonction=null;
		try{
			rs = stmt.executeQuery(requete);
			if (rs.first()) {
				//g=gd.read(rs.getString(4));
				fonction = new Fonction(rs.getLong(1), rs.getString(2));
			}
			rs.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return fonction;

	}
	public Fonction afficherUneFonctionNom(String nom) {
		String requete = "SELECT * FROM fonction WHERE nom = '" + nom + "'";
		Fonction fonction=null;
		try{
			rs = stmt.executeQuery(requete);
			if (rs.first()) {

				fonction = new Fonction(rs.getLong(1), rs.getString(2));
			}
			rs.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return fonction;

	}
	
    public List<Fonction> afficherToutFonction() {
	    List<Fonction> fonctionListe = new ArrayList<>();
	    String query = "SELECT * FROM fonction";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	long id = rs.getLong("idFonction");
	            String nom = rs.getString("nom");
	            

	            Fonction fonction1=new Fonction(id, nom);
	            fonctionListe.add(fonction1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return fonctionListe;
	}


}
