package DAO;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import systeme.CadreDeSante;


public class CadreDeSanteDAO extends DAO<CadreDeSante> {
	
	private ResultSet rs;
	
	@Override
	public CadreDeSante create(CadreDeSante cadreDeSante) {
		String requete = "INSERT INTO cadreDeSante  (nom,prenom,motDePasse) "
				+ "VALUES('" + cadreDeSante.getNom()+ "', '"+ cadreDeSante.getPrenom()+"','"+cadreDeSante.getMotdepasse()+"')";
		try {
			stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			
			ResultSet cles = stmt.getGeneratedKeys();
			if(cles.next()){
				long id = ((BigInteger)cles.getObject(1)).longValue();
				cadreDeSante.setId( id );
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cadreDeSante;
	}


	@Override
	public CadreDeSante update(CadreDeSante cadreDeSante) {
		String requete = "UPDATE cadreDeSante  SET nom ='" + cadreDeSante.getNom()+"', ";
		requete +="prenom= '"+ cadreDeSante.getPrenom()+ "', ";
		requete +="motDePasse= '"+ cadreDeSante.getMotdepasse()+ "', ";
		requete +="WHERE idContrainte = " + cadreDeSante.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cadreDeSante;

		}

	@Override
	public void delete(CadreDeSante cadreDeSante) {
		// TODO Auto-generated method stub
		String requete = "DELETE FROM cadreDeSante WHERE idCadreDeSante = " + cadreDeSante.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<CadreDeSante> afficherToutCadreDeSante() {
	    List<CadreDeSante> cadreDeSanteListe = new ArrayList<>();
	    String query = "SELECT * FROM cadreDeSante";

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	 long id = rs.getLong("identifiant");
		            String nom = rs.getString("nom");
		            String prenom = rs.getString("prénom");
		            String mdp = rs.getString("motDePasse");

		            CadreDeSante contrainte1=new CadreDeSante(id,nom,prenom,mdp);
		            cadreDeSanteListe.add(contrainte1);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	return cadreDeSanteListe;
	}
	
	public CadreDeSante afficherUnCadreDeSante(long id) {
	    String query = "SELECT * FROM cadreDeSante WHERE identifiant="+id;

	    try {
	        rs = stmt.executeQuery(query);

	        
	        while (rs.next()) {
	        	 long idC = rs.getLong("identifiant");
		            String nom = rs.getString("nom");
		            String prenom = rs.getString("prénom");
		            String mdp = rs.getString("motDePasse");

		            return new CadreDeSante(idC,nom,prenom,mdp);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	return null;
	}
}
